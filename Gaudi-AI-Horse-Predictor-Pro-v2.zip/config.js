window.GAUDI_CONFIG = {
  sources: [
    "TABPG","Racing Australia","Punters","Racing and Sports","Racing.com",
    "Equibase","At The Races","Racing Post","JRA Japan Racing",
    "Hong Kong Jockey Club","Sky Racing","Netkeiba"
  ],
  minimumRunners: 4
};
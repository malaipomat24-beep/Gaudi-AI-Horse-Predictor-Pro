const config=window.GAUDI_CONFIG;
let rowCounter=0,latestRanking=[];
const byId=id=>document.getElementById(id);
const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
const numeric=(v,f=0)=>Number.isFinite(Number.parseFloat(v))?Number.parseFloat(v):f;

byId("sourceList").innerHTML=config.sources.map((s,i)=>`<label class="source-item"><span><input type="checkbox" ${i===0?"checked":""}> ${s}</span></label>`).join("");

function addRunner(d={}){
  rowCounter++;
  const row=document.createElement("tr");
  row.innerHTML=`
    <td><input class="num" type="number" value="${d.num??rowCounter}"></td>
    <td><input class="name" value="${d.name??""}" placeholder="Horse name"></td>
    <td><input class="odds" type="number" step="0.01" value="${d.odds??""}"></td>
    <td><input class="pred" type="number" min="0" max="100" value="${d.pred??""}"></td>
    <td><input class="form" value="${d.form??""}" placeholder="12345"></td>
    <td><input class="barrier" type="number" value="${d.barrier??""}"></td>
    <td><input class="weight" type="number" step="0.5" value="${d.weight??""}"></td>
    <td><input class="jockey" type="number" min="0" max="10" step="0.5" value="${d.jockey??""}"></td>
    <td><input class="trainer" type="number" min="0" max="10" step="0.5" value="${d.trainer??""}"></td>
    <td><input class="td" type="number" min="0" max="10" step="0.5" value="${d.trackDistance??""}"></td>
    <td><input class="move" type="number" step="0.1" value="${d.marketMove??0}"></td>
    <td><input class="scratched" type="checkbox" ${d.scratched?"checked":""}></td>
    <td><button class="button secondary removeBtn">×</button></td>`;
  row.querySelector(".removeBtn").onclick=()=>row.remove();
  byId("runnerBody").appendChild(row);
}
function addFive(){for(let i=0;i<5;i++)addRunner()}
function formScore(text){
  const p=(String(text||"").match(/[0-9]/g)||[]).map(Number).filter(x=>x>0);
  if(!p.length)return 45;
  const r=p.slice(-5);let total=0,w=0;
  r.forEach((pos,i)=>{const wt=i+1;const pts=pos===1?100:pos===2?88:pos===3?78:pos===4?68:pos===5?58:Math.max(20,58-(pos-5)*6);total+=pts*wt;w+=wt});
  return total/w;
}
function collect(){
  return [...document.querySelectorAll("#runnerBody tr")].map(row=>({
    num:numeric(row.querySelector(".num").value),
    name:row.querySelector(".name").value.trim()||"Unnamed",
    odds:numeric(row.querySelector(".odds").value,20),
    pred:numeric(row.querySelector(".pred").value,50),
    form:row.querySelector(".form").value,
    barrier:numeric(row.querySelector(".barrier").value,8),
    weight:numeric(row.querySelector(".weight").value,57),
    jockey:numeric(row.querySelector(".jockey").value,5),
    trainer:numeric(row.querySelector(".trainer").value,5),
    trackDistance:numeric(row.querySelector(".td").value,5),
    marketMove:numeric(row.querySelector(".move").value,0),
    scratched:row.querySelector(".scratched").checked
  })).filter(r=>r.num>0&&!r.scratched);
}
function score(r,mode,prefs){
  const market=clamp(450/Math.max(1.01,r.odds),5,100),form=formScore(r.form);
  const barrier=clamp(100-Math.abs(r.barrier-4)*7,20,100);
  const weight=clamp(100-Math.max(0,r.weight-55)*4,25,100);
  const td=r.trackDistance*10,j=r.jockey*10,t=r.trainer*10,move=clamp(50+r.marketMove*3,0,100);
  let w={pred:.20,market:.20,form:.22,barrier:.08,weight:.06,td:.10,j:.06,t:.05,move:.03};
  if(mode==="safe")w={pred:.20,market:.28,form:.22,barrier:.08,weight:.05,td:.08,j:.04,t:.03,move:.02};
  if(mode==="value")w={pred:.18,market:.12,form:.24,barrier:.08,weight:.06,td:.12,j:.07,t:.06,move:.07};
  return clamp(r.pred*w.pred+market*w.market+form*w.form+barrier*w.barrier+weight*w.weight+td*w.td+j*w.j+t*w.t+move*w.move+(prefs.includes(r.num)?7:0),0,100);
}
const label=r=>`#${r.num} ${r.name}`;
function analyse(){
  const runners=collect();
  if(runners.length<config.minimumRunners){alert(`Enter at least ${config.minimumRunners} active runners.`);return}
  const prefs=(byId("preferred").value.match(/\d+/g)||[]).map(Number),mode=byId("riskMode").value;
  runners.forEach(r=>r.score=score(r,mode,prefs));runners.sort((a,b)=>b.score-a.score);
  latestRanking=runners.slice(0,5);
  runners.forEach((r,i)=>r.confidence=clamp(86-i*7+(r.score-runners[0].score)*.25,35,88));
  byId("raceTitle").textContent=`${byId("track").value||"Track"} • Race ${byId("raceNo").value||"-"} • ${byId("distance").value||"-"}m • ${byId("condition").value}`;
  byId("topCards").innerHTML=runners.slice(0,3).map((r,i)=>`<article class="top-card"><strong>${["TOP WIN PICK","SECOND PICK","THIRD PICK"][i]}</strong><h3>${label(r)}</h3><p>Score ${r.score.toFixed(1)} • Confidence ${r.confidence.toFixed(0)}% • Odds ${r.odds.toFixed(2)}</p></article>`).join("");
  const [a,b,c,d,e]=runners,outsider=[...runners].filter(r=>r.odds>=8).sort((x,y)=>y.score-x.score)[0]||e;
  const bets=[
    ["Single Win",label(a)],["Exacta",`${a.num} → ${b.num}`],["Exacta Box",`${a.num}, ${b.num}, ${c.num}`],
    ["Trifecta",`${a.num} → ${b.num} → ${c.num}`],["Trifecta Box",`${a.num}, ${b.num}, ${c.num}, ${d.num}`],
    ["First 4 #1",`${a.num}-${b.num}-${c.num}-${d.num}`],["First 4 #2",`${a.num}-${c.num}-${b.num}-${d.num}`],
    ["First 4 #3",`${b.num}-${a.num}-${c.num}-${d.num}`],["First 4 #4",`${a.num}-${b.num}-${d.num}-${e.num}`],
    ["Best Outsider",`${label(outsider)} at ${outsider.odds.toFixed(2)}`]
  ];
  byId("betGrid").innerHTML=bets.map(x=>`<article class="bet-card"><strong>${x[0]}</strong><br>${x[1]}</article>`).join("");
  byId("rankingBody").innerHTML=runners.map((r,i)=>`<tr><td>${i+1}</td><td>${label(r)}</td><td>${r.score.toFixed(1)}</td><td>${r.confidence.toFixed(0)}%</td><td>${i===0?"Strongest profile":i===1?"Main danger":i===2?"Strong place chance":r.odds>=8&&r.score>=60?"Value outsider":"Higher risk"}</td></tr>`).join("");
  byId("resultsCard").classList.remove("hidden");byId("resultsCard").scrollIntoView({behavior:"smooth"});
}
function compare(){
  const actual=(byId("officialResult").value.match(/\d+/g)||[]).map(Number),pred=latestRanking.map(r=>r.num);
  if(!actual.length||!pred.length){byId("comparisonBox").textContent="Generate a prediction and enter the official result first.";return}
  byId("comparisonBox").innerHTML=`Top Win Pick: <strong>${actual[0]===pred[0]?"WON":"LOST"}</strong><br>Trifecta Box coverage: <strong>${pred.slice(0,3).every(n=>actual.slice(0,3).includes(n))?"HIT":"MISSED"}</strong><br>First 4 top-four coverage: <strong>${pred.slice(0,4).every(n=>actual.slice(0,4).includes(n))?"HIT":"MISSED"}</strong>`;
}
function saveRace(){
  const meta={};["track","raceNo","distance","condition","raceClass","preferred","riskMode","meetingDate","raceNotes"].forEach(k=>meta[k]=byId(k).value);
  localStorage.setItem("gaudiHorseRace",JSON.stringify({meta,runners:collect()}));alert("Race saved on this phone.");
}
function loadRace(){
  const raw=localStorage.getItem("gaudiHorseRace");if(!raw){alert("No saved race was found.");return}
  const data=JSON.parse(raw);Object.entries(data.meta).forEach(([k,v])=>{if(byId(k))byId(k).value=v});
  byId("runnerBody").innerHTML="";rowCounter=0;data.runners.forEach(addRunner);
}
byId("addRunnerBtn").onclick=()=>addRunner();byId("addFiveBtn").onclick=addFive;byId("analyseBtn").onclick=analyse;
byId("compareBtn").onclick=compare;byId("saveBtn").onclick=saveRace;byId("loadBtn").onclick=loadRace;
byId("screenshotInput").onchange=e=>{const f=e.target.files[0];if(!f)return;byId("preview").src=URL.createObjectURL(f);byId("preview").style.display="block"};
addFive();
if("serviceWorker"in navigator)navigator.serviceWorker.register("service-worker.js").catch(()=>{});

# Gaudi AI Horse Predictor Pro v2.0

Mobile-friendly GitHub Pages website for manually entering visible race information and generating structured selections.

Files:
- index.html
- style.css
- script.js
- config.js
- manifest.json
- service-worker.js

Important: Predictions are estimates and cannot guarantee winners.
